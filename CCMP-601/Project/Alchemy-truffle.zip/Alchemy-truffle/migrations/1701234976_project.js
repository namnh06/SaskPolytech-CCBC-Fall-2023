var v_Project = artifacts.require('./project.sol');
module.exports = function(_deployer) {
  _deployer.deploy(v_Project);
};
